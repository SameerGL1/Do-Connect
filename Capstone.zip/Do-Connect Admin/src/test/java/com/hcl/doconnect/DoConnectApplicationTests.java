package com.hcl.doconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class doconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
