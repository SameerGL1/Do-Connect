package com.hcl.doconnect.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.doconnect.model.User;
import com.hcl.doconnect.repository.UserRepository;
 
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;
 
    @Autowired
    private UserService userService;
 
    @Test
    public void testRegisterUser() {
        // Mocking repository behavior
        User user = new User();
        user.setUsername("tarun");
        user.setPassword("tarun");
        when(userRepository.save(any(User.class))).thenReturn(user);
        User registeredUser = userService.registerUser(user);
          System.out.println(registeredUser.getPassword());
        assertNotNull(registeredUser);
        assertEquals(user.getUsername(), registeredUser.getUsername());
    assertEquals("password",registeredUser.getPassword());
    }
    
    @Test
    public void testLoginUser_ValidCredentials() {
        // Mock user data
        String username = "testuser";
        String password = "password";
        User user = new User(username, password, "USER");
 
        // Mock UserRepository behavior
        when(userRepository.findByUsernameAndPassword(username, password)).thenReturn(user);
 
        // Call the loginUser method
        User loggedInUser = userService.loginUser(username, password);
 
        // Verify that the returned user is not null
        assertEquals(user, loggedInUser);
    }
 
    @Test
    public void testLoginUser_InvalidCredentials() {
        // Mock user data
        String username = "testuser";
        String password = "wrongpassword";
 
        // Mock UserRepository behavior to return an empty optional
        when(userRepository.findByUsernameAndPassword(username, password)).thenReturn(null);
 
        // Call the loginUser method
        User loggedInUser = userService.loginUser(username, password);
 
        // Verify that the returned user is null
        assertEquals(null, loggedInUser);
    }
}