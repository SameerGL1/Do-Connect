package com.hcl.doconnect.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hcl.doconnect.model.Notification;


public interface NotificationService {
	List<Notification> getAllNotification();

	List<Notification> getAllUnreadNotifications();

	Notification getNotificationsById(Long id);

	void markedNotificationSeen(Notification notification);
}
