package com.hcl.doconnect.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.dto.AnswerDetailsDTO;
import com.hcl.doconnect.dto.CommentDetailsDTO;
import com.hcl.doconnect.dto.QuestionDetailsDTO;
import com.hcl.doconnect.exception.QuestionNotFoundException;
import com.hcl.doconnect.model.Answer;
import com.hcl.doconnect.model.Comment;
import com.hcl.doconnect.model.Notification;
import com.hcl.doconnect.model.Question;
import com.hcl.doconnect.repository.AnswerRepository;
import com.hcl.doconnect.repository.CommentRepository;
import com.hcl.doconnect.repository.NotificationRepository;
import com.hcl.doconnect.repository.QuestionRepository;

@Service
public class QuestionServiceImpl implements QuestionService {

    @Autowired
    private QuestionRepository questionRepository;
    @Autowired
    private AnswerRepository answerRepository;
    @Autowired
    private CommentRepository commentRepository;
    @Autowired
    private NotificationRepository notificationRepository;

    @Override
    public Question findById(Long id) throws QuestionNotFoundException {
        Optional<Question> optionalQuestion = questionRepository.findById(id);
        return optionalQuestion.orElseThrow(() -> new QuestionNotFoundException("Question Not Found With Give id = "+ id));
    }

    @Override
    public List<Question> findAll() {
        return questionRepository.findAll();
    }

 

    @Override
    public Question saveQuestion(Question question) {
    
        return questionRepository.save(question);
    }

	@Override
	public List<Question> searchQuestions(String searchString) {
		
		List<Question> approvedQuestions = questionRepository.findByContentContainingIgnoreCaseAndStatus(searchString, "APPROVED");

        return approvedQuestions;
    }

	@Override
    public List<Question> getAllApprovedQuestions() {
        return questionRepository.findByStatus("APPROVED");
    }



	@Override
    public Question updateQuestion(Long id, Question question) {
        Question existingQuestion = questionRepository.findById(id).orElse(null);
        if (existingQuestion != null) {
            question.setId(id);
            return questionRepository.save(question);
        }
        return null;
    }

	@Override
	public void deleteQuestion(Long id) {
		
		
		questionRepository.deleteById(id);
	}

	@Override
	public boolean approveQuestion(Long id) {
        Optional<Question> optionalQuestion = questionRepository.findById(id);
        if (optionalQuestion.isPresent()) {
            Question question = optionalQuestion.get();
            question.setStatus("APPROVED"); // Set the question as approved
            questionRepository.save(question);
            return true;
        }
        return false;
    }
	
	
	@Override
	 public boolean closeDiscussion(Long id) {
	        Optional<Question> optionalQuestion = questionRepository.findById(id);
	        if (optionalQuestion.isPresent()) {
	            Question question = optionalQuestion.get();
	            question.setStatus("RESOLVED"); // Update the status of the question
	            questionRepository.save(question);
	            return true;
	        }
	        return false;
	    }

		@Override
		public QuestionDetailsDTO getQuestionDetails(long id) throws QuestionNotFoundException {

			QuestionDetailsDTO questionDetailsDTO = new QuestionDetailsDTO();
			Question question = findById(id);
			if (question != null) {
				questionDetailsDTO.setQuestion(question);
			}
			List<AnswerDetailsDTO> ansDetailsDTOList = new ArrayList<>();

			List<Answer> answers = answerRepository.findByQuestionId(null);
			AnswerDetailsDTO answerDetailsDTO = new AnswerDetailsDTO();
			CommentDetailsDTO commentDetailsDTO = new CommentDetailsDTO();

			if (answers != null) {

				for (Answer ans : answers) {
					answerDetailsDTO = new AnswerDetailsDTO();
					answerDetailsDTO.setAnswer(ans);

					List<Comment> comments = commentRepository.findByAnswerId(ans.getId());

					if (comments != null) {
						
						answerDetailsDTO.setComments(comments);
						
					}
					
					ansDetailsDTOList.add(answerDetailsDTO);
				}
				questionDetailsDTO.setAnswers(ansDetailsDTOList);
				return questionDetailsDTO;
			}
			
			return null;

		}

		@Override
		public List<Question> getAllPendingQuestions() {
			 return questionRepository.findByStatus("PENDING");
		
		}
		
	
		@Override
		public List<Question> getAllResolvedQuestions() {
			return questionRepository.findByStatus("RESOLVED");
			
		}
	

    // Add other methods as needed
}
