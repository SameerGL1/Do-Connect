package com.hcl.doconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.model.Notification;
import com.hcl.doconnect.repository.NotificationRepository;

@Service
public class NotificationServiceImpl implements NotificationService {
	
	@Autowired
	private NotificationRepository notificationRepository;

	@Override
	public List<Notification> getAllNotification() {
		
		return notificationRepository.findAll();
		
	}

	@Override
	public List<Notification> getAllUnreadNotifications() {
	
		return notificationRepository.findUnseenNotificationsSortedByDate();
	}

	@Override
	public Notification getNotificationsById(Long id) {
		
		return notificationRepository.findById(id).orElse(null);
	}

	@Override
	public void markedNotificationSeen(Notification notification) {
		
		notificationRepository.save(notification);
		
	}

}
