package com.hcl.doconnect.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hcl.doconnect.dto.AnswerDTO;
import com.hcl.doconnect.dto.CommentDTO;
import com.hcl.doconnect.dto.QuestionDTO;
import com.hcl.doconnect.dto.QuestionDetailsDTO;
import com.hcl.doconnect.dto.UserLoginDTO;
import com.hcl.doconnect.dto.UserRegisterDTO;
import com.hcl.doconnect.exception.AnswerNotFoundException;
import com.hcl.doconnect.exception.QuestionNotFoundException;
import com.hcl.doconnect.exception.UserNotFoundException;
import com.hcl.doconnect.model.Answer;
import com.hcl.doconnect.model.Comment;
import com.hcl.doconnect.model.Notification;
import com.hcl.doconnect.model.Question;
import com.hcl.doconnect.model.User;
import com.hcl.doconnect.repository.NotificationRepository;
import com.hcl.doconnect.repository.QuestionRepository;
import com.hcl.doconnect.service.AnswerService;
import com.hcl.doconnect.service.CommentService;
import com.hcl.doconnect.service.NotificationService;
import com.hcl.doconnect.service.QuestionService;
import com.hcl.doconnect.service.UserService;

import io.swagger.v3.oas.annotations.Hidden;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
	// Autowire UserService
	@Autowired
	private UserService userService;

	@Autowired
	private QuestionService questionService;

	@Autowired
	private AnswerService answerService;

	private User authAdmin;

	@Autowired
	private QuestionRepository questionRepository;

	@Autowired
	private CommentService commentService;
	
    @Autowired
    private NotificationRepository notificationRepository;
	
	private static final String APPROVED = "APPROVED";
	private static final String RESOLVED = "RESOLVED";

	private User authUser;

	@Autowired
	private NotificationService notificationService;

	public User getAuthUser() {
		return authUser;
	}

//	Register Admin Api
	@PostMapping("/register")
	public ApiResponse<User> registerAdmin(@RequestBody UserRegisterDTO userRegisterDTO) {
		User user = new User();
		user.setUsername(userRegisterDTO.getUsername());
		user.setPassword(userRegisterDTO.getPassword());
		User registeredAdmin = userService.registerAdmin(user);
		return new ApiResponse<>("Admin registered successfully", registeredAdmin);
	}

	@Hidden
	@PostMapping("/user/register")
	public User registerUser(@RequestBody User user) {
		
		User registeredUser = userService.registerUser(user);

		return  registeredUser;
	}

//	Login Admin Api
	@PostMapping("/login")
	public ApiResponse<User> loginAdmin(@RequestBody UserLoginDTO userRegisterDTO) {
		User user = new User();
		user.setUsername(userRegisterDTO.getUsername());
		user.setPassword(userRegisterDTO.getPassword());
		User loggedInAdmin = userService.loginUser(user.getUsername(), user.getPassword());
		if (loggedInAdmin != null && loggedInAdmin.getRole().equals("ADMIN")) {
			authAdmin = loggedInAdmin;
			return new ApiResponse<>("Admin logged in successfully", loggedInAdmin);
		} else {
			return new ApiResponse<>("Admin not found", user);
		}

	}

	

//	Logout Admin Api
	@GetMapping("/logout")
	public ApiResponse<User> logoutUser() {
		if (authAdmin == null) {
			return new ApiResponse<User>("Unauthorized user trying to access data, You need to login first", null);
		}
		userService.logoutUser(null);
		authAdmin = null;
		return new ApiResponse<User>("User logged out successfully", authAdmin);
	}

//	 Get all User
	@GetMapping("/allusers")
	public ApiResponse<List<User>> getAllUsers() {
		if (authAdmin != null) {
			List<User> users = userService.getAllUsers();
			return new ApiResponse<>("User List Founded", users);

		}
		return new ApiResponse<>("Unauthorized user trying to access data, You need to authorized first", null);
	}

//	 Get user By ID
	@GetMapping("/user/{id}")
	public ApiResponse<User> getUserById(@PathVariable Long id) {
		if (authAdmin == null) {
			return new ApiResponse<>("Unauthorized user trying to access data, You need to authorized first", null);
		}
		User user = userService.findById(id);
		if (user != null) {

			return new ApiResponse<>("User founded  successfully", user);
		} else {
			return new ApiResponse<>("User not found with given ID = " + id, user);
		}

	}

//		Delete User by ID
	@DeleteMapping("/delete/user/{id}")
	public ApiResponse<User> deleteUser(@PathVariable Long id) {

		if (authAdmin == null) {
			return new ApiResponse<User>("Unauthorized user trying to access data, You need to authorized first", null);
		}
		User user = userService.findById(id);
		if (user != null) {
			userService.delete(user);
			return new ApiResponse<>("User deleted successfully", user);
		} else {
			return new ApiResponse<>("User not found", user);
		}
	}
	

//		Update User By ID
	@PutMapping("/update/user/{id}")
	public ApiResponse<User> updateUser(@PathVariable Long id, @RequestBody User user) throws UserNotFoundException {
		if (authAdmin == null) {
			return new ApiResponse<>("Unauthorized user trying to access data, You need to authorized first", null);
		}
		User updatedUser = userService.updateUser(id, user);
		if (updatedUser != null) {
			return new ApiResponse<>("User updated Succesfully ", updatedUser);
		} else {
			throw new UserNotFoundException("User not found with ID = " + user);
		}
	}

//		CRUD Operations on Questions.

//		Get All Questions
	@GetMapping("/questions")
	public ResponseEntity<?> getAllQuestions() {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		List<Question> questions = questionService.findAll();
		return ResponseEntity.ok().body(questions);
	}
	
	
//  view All approved questions
  @GetMapping("/questions/viewall")
  public ResponseEntity<?> getAllApprovedQuestions() {
  	if(authAdmin==null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

  	List<Question> approvedQuestions = questionService.getAllApprovedQuestions();
      if(approvedQuestions == null) return  ResponseEntity.ok().body("No Approved Question At this time. ");

      return ResponseEntity.ok().body(approvedQuestions);
  }


//		get question by ID
	@GetMapping("/question/{id}")
	public ResponseEntity<?> getQuestionById(@PathVariable Long id) throws QuestionNotFoundException {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		Question question = questionService.findById(id);
		if (question != null) {
			return ResponseEntity.ok().body(question);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

//  view All Pending questions
	@GetMapping("questions/viewallpending")
	public ResponseEntity<?> getAllPendingQuestions() {
		if (authAdmin == null)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

		List<Question> approvedQuestions = questionService.getAllPendingQuestions();
		if (approvedQuestions == null)
			return ResponseEntity.ok().body("No Approved Question At this time. ");

		return ResponseEntity.ok().body(approvedQuestions);
	}



//  view All Resolved questions
	@GetMapping("questions/viewallresolved")
	public ResponseEntity<?> getAllResolvedQuestions() {
		if (authAdmin == null)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

		List<Question> approvedQuestions = questionService.getAllResolvedQuestions();
		if (approvedQuestions == null)
			return ResponseEntity.ok().body("No Approved Question At this time. ");

		return ResponseEntity.ok().body(approvedQuestions);
	}

//		create question
	@PostMapping("/question/post")
	public ResponseEntity<?> createQuestion(@RequestBody Question question) {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		Question createdQuestion = questionService.saveQuestion(question);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdQuestion);
	}

//	    Update question by id
	@PutMapping("/question/update/{id}")
	public ResponseEntity<?> updateQuestion(@PathVariable Long id, @RequestBody Question question)
			throws QuestionNotFoundException {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		Question updatedQuestion = questionService.updateQuestion(id, question);
		if (updatedQuestion != null) {
			return ResponseEntity.ok().body(updatedQuestion);
		} else {
			throw new QuestionNotFoundException("Question Not Found With Give id = " + id);
		}
	}

//	    Delete Question by ID
	@DeleteMapping("/question/delete/{id}")
	public ResponseEntity<?> deleteQuestion(@PathVariable Long id) {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		questionService.deleteQuestion(id);
		return ResponseEntity.noContent().build();
	}

//		Add answer to question with id
	@PostMapping("/add/answer")
	public ApiResponse<Object> addAnswer(@RequestBody AnswerDTO answerDTO) throws QuestionNotFoundException {
		if (authAdmin == null) {

			return new ApiResponse<>("You are not an authorized user", null);
		}
		Optional<Question> optionalQuestion = questionRepository.findById(answerDTO.getQuestionId());
		if (optionalQuestion.isPresent()) {
			Answer answer = new Answer();
			answer.setContent(answerDTO.getContent());
			answer.setStatus("PENDING"); // Assuming all answers are pending approval by admin
			answer.setUser(authAdmin);
			answer.setQuestion(questionService.findById(answerDTO.getQuestionId()));

			Answer savedAnswer = answerService.save(answer);
			return new ApiResponse<>("Answer posted successfully but pending with Admin", savedAnswer);
		}
		return new ApiResponse<>("Questions not found with given Id", answerDTO);

	}

//	    Approve Question By ID
	// Method to approve a question
	@PutMapping("/approve/questions/{id}")
	public ResponseEntity<?> approveQuestion(@PathVariable Long id) throws QuestionNotFoundException {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		boolean approved = questionService.approveQuestion(id);
		if (approved) {
			return ResponseEntity.ok().body("Question approved successfully");
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body((new ApiResponse<>("Discussion closed successfully", questionService.findById(id))));
		}
	}

	// Method to close discussion thread for a question and update status
	@PutMapping("/questions/closediscussion/{id}")
	public ResponseEntity<?> closeDiscussion(@PathVariable Long id) throws QuestionNotFoundException {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		boolean closed = questionService.closeDiscussion(id);
		if (closed) {

			return ResponseEntity.ok()
					.body(new ApiResponse<>("Discussion closed successfully", questionService.findById(id)));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.body(new ApiResponse<Object>("Question not found", null));
		}
	}

	
//  view All Pending Answer
	@GetMapping("answer/viewallpending")
	public ResponseEntity<?> getAllPendingAnswer() {
		if (authAdmin == null)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

		List<Answer> approvedQuestions = answerService.getAllPendingAnswer();
		if (approvedQuestions == null)
			return ResponseEntity.ok().body("No Approved Question At this time. ");

		return ResponseEntity.ok().body(approvedQuestions);
	}
	
//  view All Approved Answer
	@GetMapping("answer/viewallapproved")
	public ResponseEntity<?> getAllApprovedAnswer() {
		if (authAdmin == null)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		
		List<Answer> approvedQuestions = answerService.getAllApprovedAnswer();
		if (approvedQuestions == null)
			return ResponseEntity.ok().body("No Approved Question At this time. ");
		
		return ResponseEntity.ok().body(approvedQuestions);
	}
	
	
	// Method to approve an answer
	@PutMapping("/answers/approve/{id}")
	public ResponseEntity<?> approveAnswer(@PathVariable Long id) {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		boolean approved = answerService.approveAnswer(id);
		if (approved) {
			return ResponseEntity.ok().body(new ApiResponse<Object>("Answer approved successfully", null));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<Object>("Answer not found", null));
		}
	}

	// Method to delete an answer
	@DeleteMapping("/delete/answers/{id}")
	public ResponseEntity<?> deleteAnswer(@PathVariable Long id) {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		boolean deleted = answerService.deleteAnswer(id);
		if (deleted) {
			return ResponseEntity.ok().body(new ApiResponse<>("Answer deleted successfully", null));
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<>("Answer not found", null));
		}
	}

//	Get FUll details of Question with ID

	@GetMapping("/question/{id}/details")
	public ResponseEntity<?> getQuestionDetails(@PathVariable long id) throws QuestionNotFoundException {
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}

		QuestionDetailsDTO questionDetailsDTO = questionService.getQuestionDetails(id);
		if (questionDetailsDTO != null) {

			return ResponseEntity.ok().body(new ApiResponse<>("Questions details founded", questionDetailsDTO));
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<>("Questions Details not found", null));
	}
	
	
//	API for Mail
	
//	get All Mails
	
	@GetMapping("/notifications")
	public ResponseEntity<?> getAllNotifications(){
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		List<Notification> notifications = notificationService.getAllNotification();
		return ResponseEntity.ok().body(notifications); 
	}
	
//	get Unseen Mails
	
	@GetMapping("/notifications/unread")
	public ResponseEntity<?> getAllUnreadNotifications(){
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		List<Notification> notifications = notificationService.getAllUnreadNotifications();
		return ResponseEntity.ok().body(notifications); 
	}
	
//	get Mails By ID
	
	@GetMapping("/notifications/{id}")
	public ResponseEntity<?> getNotificationsById(@PathVariable Long id){
		if (authAdmin == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		
		Notification notification = notificationService.getNotificationsById(id);
		if(notification != null) {
			if(notification.getStatus().equals("UNSEEN")) {
				notification.setStatus("SEEN");
				notificationService.markedNotificationSeen(notification);
			}
			return ResponseEntity.ok().body(new ApiResponse<>("Notification details founded ", notification)); 
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<>("Notification Details not found with give id = "+id, null));
	}
	
	
//	API for User MicroServices
	
	
//	User Login API
	
	@ApiIgnore
	@PostMapping("/user/login")
	public User loginUser(@RequestBody UserLoginDTO userDTO) {
		User loggedInUser = userService.loginUser(userDTO.getUsername(), userDTO.getPassword());
	
		if (loggedInUser != null && loggedInUser.getRole().equals("USER")) {
			authUser = loggedInUser;
		}
		return loggedInUser;
		
	}
	
//	Ask Question by User
	@ApiIgnore
	@PostMapping("user/question/ask")
	public Question askQuestion(@RequestBody QuestionDTO questionDTO) {

		Question question = new Question();
		
		question.setUser(authUser);
		question.setTopic(questionDTO.getTopic());
		question.setContent(questionDTO.getContent());
		question.setStatus("PENDING");

		Question savedQuestion = questionService.saveQuestion(question);
		
		Notification notification = new Notification("User with id = "+authUser.getId()+ " added the question with id = "+savedQuestion.getId() + " but pending with you." , "UNSEEN" , LocalDateTime.now());
		notificationRepository.save(notification);
		return savedQuestion;
		
	}
	
	
//  Search Question based on String.
	@ApiIgnore
	@GetMapping("/user/questions/search/{word}")
	public List<Question> searchQuestions(@PathVariable String word) {
		
		List<Question> foundQuestions = questionService.searchQuestions(word);
		
		return foundQuestions;
		
	}
	
//  view All approved questions
	@GetMapping("/user/questions/viewall")
	@ApiIgnore
	public List<Question> viewAllApprovedQuestions() {
		
		List<Question> approvedQuestions = questionService.getAllApprovedQuestions();
		
		return approvedQuestions;
	}
	
//	get question by ID
	@GetMapping("user/question/{id}")
	@ApiIgnore
	public Question viewQuestionById(@PathVariable Long id) throws QuestionNotFoundException {
		
		Question question = questionService.findById(id);
		if (question != null && question.getStatus().equals(APPROVED)) {
			return question;
		} else {
			return null;
		}
	}
	
//	Add answer to question with id
	@PostMapping("/user/add/answer")
	@ApiIgnore
	public ApiResponse<Object> addAnswerByUser(@RequestBody AnswerDTO answerDTO) throws QuestionNotFoundException {
		
		Optional<Question> optionalQuestion = questionRepository.findById(answerDTO.getQuestionId());
		if (optionalQuestion.isPresent() && optionalQuestion.get().getStatus().equals(RESOLVED)) {
			return new ApiResponse<>("Discussion Closed with Question id = " + answerDTO.getQuestionId(),
					optionalQuestion.get());
		} else if (optionalQuestion.isPresent() && optionalQuestion.get().getStatus().equals(APPROVED)) {
			Answer answer = new Answer();
			answer.setContent(answerDTO.getContent());
			answer.setStatus("PENDING"); // Assuming all answers are pending approval by admin
			answer.setUser(authUser);
			answer.setQuestion(optionalQuestion.get());

			Answer savedAnswer = answerService.save(answer);
			Notification notification = new Notification("User with id = "+authUser.getId()+ " added the Answer with id = "+savedAnswer.getId() + " but pending with you." , "UNSEEN" , LocalDateTime.now());
			notificationRepository.save(notification);
			return new ApiResponse<>("Answer posted successfully but pending with Admin", savedAnswer);
		}
		return new ApiResponse<>("Questions not found with given Id", answerDTO);

	}
	
	
//	like answer with answer id
	@PostMapping("/user/like/answer/{answerId}")
	@ApiIgnore
	public ApiResponse<?> likeAnswer(@PathVariable Long answerId) {
		
		Answer answer = answerService.findById(answerId);
		if (answer != null && answer.getStatus().equals(APPROVED)) {

			// Implemented logic to like the answer
			// increment the like count for the answer
			answer.setLikes(answer.getLikes() + 1);
			// Save the updated answer
			Answer updatedAnswer = answerService.save(answer);
			return new ApiResponse<>("Answer liked successfully", updatedAnswer);
		}
		return new ApiResponse<>("Answer not found with id = " + answerId, null);

	}
	
	
	// Comment on Answer with answer ID
	@PostMapping("/user/answer/comment")
	@ApiIgnore
	public ApiResponse<Comment> addCommentToAnswer(@RequestBody CommentDTO commentDTO) throws AnswerNotFoundException {
		
		Answer answer = answerService.findById(commentDTO.getAnswerId());

		if (answer != null && answer.getStatus().equals(APPROVED)) {
			Comment savedComment = commentService.addComment(commentDTO.getAnswerId(), commentDTO, authUser);
			return new ApiResponse<>("Comment added successfully", savedComment);

		}
		return new ApiResponse<>("Answer not found with id = " + commentDTO.getAnswerId(), null);
	}



	
	
}