package com.hcl.doconnect.dto;

public class SearchQuestionAnswerDTO {
	private String word;
	

	public SearchQuestionAnswerDTO(String word) {
		super();
		this.word = word;
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}
	
	
}
