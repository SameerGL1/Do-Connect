package com.hcl.doconnect.service;

import java.util.List;

import com.hcl.doconnect.dto.QuestionDetailsDTO;
import com.hcl.doconnect.exception.QuestionNotFoundException;
import com.hcl.doconnect.model.Question;

public interface QuestionService {
    Question findById(Long id) throws QuestionNotFoundException;
    List<Question> findAll();
	Question saveQuestion(Question question);
	List<Question> searchQuestions(String searchString);
	
	Question updateQuestion(Long id, Question question);
	void deleteQuestion(Long id);
	boolean approveQuestion(Long id);
	boolean closeDiscussion(Long id);
	QuestionDetailsDTO getQuestionDetails(long id) throws QuestionNotFoundException;
	List<Question> getAllApprovedQuestions();
	List<Question> getAllPendingQuestions();
	List<Question> getAllResolvedQuestions();
}
