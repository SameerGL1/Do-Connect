package com.hcl.doconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.doconnect.model.AuthRequest;
import com.hcl.doconnect.util.JwtUtil;


@RestController
@RequestMapping("/")
public class TokenController {

	@Autowired //Marks a constructor, field, setter method.
	JwtUtil jwtUtil;

	//Generation for JWT Token 
	@PostMapping("/getToken")
	public String getToken(@RequestBody AuthRequest request) {
		//Validation
		if (request.getUname().equals("owner") && request.getPassword().equals("owner123")) {
			String token = jwtUtil.generateToken(request.getUname());
			return token; //Returning the token details
		} else {
			return "Bad/Invalid Credential";
		}
	}
}
