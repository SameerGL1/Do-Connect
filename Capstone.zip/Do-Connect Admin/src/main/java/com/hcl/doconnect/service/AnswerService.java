package com.hcl.doconnect.service;

import java.util.List;

import com.hcl.doconnect.model.Answer;

public interface AnswerService {

	Answer findById(Long id);
    Answer save(Answer answer);
    void delete(Answer answer);
    // Add other methods as needed
	boolean approveAnswer(Long id);
	boolean deleteAnswer(Long id);
	List<Answer> getAllPendingAnswer();
	List<Answer> getAllApprovedAnswer();
}
