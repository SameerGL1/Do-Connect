package com.hcl.doconnect.service;

import com.hcl.doconnect.model.User;
import com.hcl.doconnect.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    
    

    @Override
    public User findById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void delete(User user) {
        userRepository.delete(user);
    }

    @Override
    public User registerUser(User user) {
    	user.setRole("USER");
    	user.setQuestions(new ArrayList<>());
    	user.setAnswers(new ArrayList<>());
        return userRepository.save(user);
    }

    @Override
    public User loginUser(String username, String password) {
        return userRepository.findByUsernameAndPassword(username, password);
    }

    @Override
    public void logoutUser(String username) {
       
    }

	@Override
	public User registerAdmin(User user) {
		user.setRole("ADMIN");
    	user.setQuestions(new ArrayList<>());
    	user.setAnswers(new ArrayList<>());
        return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findByRole("USER");
	}

	@Override
	public User updateUser(Long id, User user) {
		User existingUser = userRepository.findById(id).orElse(null);
		if(existingUser != null) {
			existingUser.setUsername(user.getUsername());
			existingUser.setPassword(user.getPassword());
			existingUser.setRole(user.getRole());
			
			return userRepository.save(existingUser);
		}
		return null;
	}

    // Additional methods for user management
}
