package com.hcl.doconnect;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import com.hcl.doconnect.controller.ApiResponse;
import com.hcl.doconnect.controller.UserController;
import com.hcl.doconnect.model.AuthRequest;
import com.hcl.doconnect.model.User;
import com.hcl.doconnect.service.UserServiceImpl;
import com.hcl.doconnect.util.JwtUtil;
 
@ExtendWith(MockitoExtension.class)
public class DoConnectApplicationTests {
    @Mock
    private UserServiceImpl userService;
    @Mock
    private JwtUtil jwtUtil;
    @InjectMocks
    private UserController userController;
    private User testUser;
    private AuthRequest testauthRequest;
    private List<User> userList;
    @BeforeEach
    public void setUp() {
        testUser = new User();
        testauthRequest = new AuthRequest("testUsername", "testPassword");
        userList = new ArrayList<>();
        userList.add(testUser);
    }
    @Test
    public void testUserRegister_Success() {
        when(userService.findById(anyLong()));
        ApiResponse<User> response = userController.registerUser(testUser);
        verify(userService, times(1)).registerUser(testUser);
        assert(response.getMessage()).equals(HttpStatus.CREATED);
    }
    @Test
    public void testUserRegister_AlreadyRegistered() {
        when(userService.findById(anyLong()));
        ApiResponse<User> response = userController.registerUser(testUser);
        assert(response.getMessage()).equals(HttpStatus.BAD_REQUEST);
    }
    @Test
    public void testUserLogin_Success() {
        when(userService.getAllUsers()).thenReturn(userList);
        when(jwtUtil.generateToken(toString())).thenReturn("testToken");
        ApiResponse<User> response = userController.loginUser(testauthRequest);
        assert(response.equals("testToken"));
    }
    @Test
    public void testUserLogin_InvalidCredentials() {
        when(userService.getAllUsers()).thenReturn(userList);
        AuthRequest invalidLoginRequest = new AuthRequest("invalidUsername", "invalidPassword");
        ApiResponse<User> response = userController.loginUser(invalidLoginRequest);
        assert(response.equals("Bad/Invalid Credentials Check And Try To Login Again"));
    }
    // Add more test cases for other methods if needed
}