package com.hcl.doconnect.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.doconnect.controller.ApiResponse;
import com.hcl.doconnect.model.User;
import com.hcl.doconnect.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    
    

    @Override
    public User findById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void delete(User user) {
        userRepository.delete(user);
    }

    @Override
    public User registerUser(User user) {
    	
    	RestTemplate restTemplate = new RestTemplate();
    	
    	user =  restTemplate.postForObject("http://localhost:8080/api/admin/user/register", user, User.class);
    	
    	return user;
    	
       
    }



    @Override
    public void logoutUser(String username) {
       
    }

	@Override
	public User registerAdmin(User user) {
		user.setRole("ADMIN");
    	user.setQuestions(new ArrayList<>());
    	user.setAnswers(new ArrayList<>());
        return userRepository.save(user);
	}

	@Override
	public List<User> getAllUsers() {
		return userRepository.findByRole("USER");
	}

	@Override
	public User updateUser(Long id, User user) {
		User existingUser = userRepository.findById(id).orElse(null);
		if(existingUser != null) {
			existingUser.setUsername(user.getUsername());
			existingUser.setPassword(user.getPassword());
			existingUser.setRole(user.getRole());
			
			return userRepository.save(existingUser);
		}
		return null;
	}

	@Override
	public User loginUser(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

    // Additional methods for user management
}
