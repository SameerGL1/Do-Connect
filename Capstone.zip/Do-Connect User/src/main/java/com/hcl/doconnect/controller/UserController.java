package com.hcl.doconnect.controller;

import com.hcl.doconnect.dto.AnswerDTO;
import com.hcl.doconnect.dto.CommentDTO;
import com.hcl.doconnect.dto.QuestionDTO;
import com.hcl.doconnect.dto.QuestionDetailsDTO;
import com.hcl.doconnect.dto.UserLoginDTO;
import com.hcl.doconnect.dto.UserRegisterDTO;
import com.hcl.doconnect.exception.AnswerNotFoundException;
import com.hcl.doconnect.exception.QuestionNotFoundException;
import com.hcl.doconnect.exception.UserNotFoundException;
import com.hcl.doconnect.model.Answer;
import com.hcl.doconnect.model.Comment;
import com.hcl.doconnect.model.Question;
import com.hcl.doconnect.model.User;
import com.hcl.doconnect.repository.QuestionRepository;
import com.hcl.doconnect.service.AnswerService;
import com.hcl.doconnect.service.CommentService;
import com.hcl.doconnect.service.QuestionService;
import com.hcl.doconnect.service.UserService;
import com.hcl.doconnect.util.JwtUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private UserService userService;

	@Autowired
	private QuestionService questionService;

	@Autowired
	private QuestionRepository questionRepository;

	@Autowired
	private AnswerService answerService;

	@Autowired
	private CommentService commentService;

	private static final String APPROVED = "APPROVED";
	private static final String RESOLVED = "RESOLVED";
	private User authUser;

	public User getAuthUser() {
		return authUser;
	}

	public void setAuthUser(User authUser) {
		this.authUser = authUser;
	}

	@PostMapping("/register")
	public ApiResponse<User> registerUser(@RequestBody UserRegisterDTO userDTO) {
		User user = new User();
		user.setUsername(userDTO.getUsername());
		user.setPassword(userDTO.getPassword());
		user.setRole("USER");
		user.setQuestions(new ArrayList<>());
		user.setAnswers(new ArrayList<>());
		
		RestTemplate restTemplate = new RestTemplate();
		
//		calling Admin Microservice for processing the data
		 
		user = restTemplate.postForObject("http://localhost:8080/api/admin/user/register", user, User.class);

		return new ApiResponse<>("User registered successfully", user);
	}

	@PostMapping("/login")
	public ApiResponse<User> loginUser(@RequestBody UserLoginDTO userDTO) {
		
		
		RestTemplate restTemplate = new RestTemplate();
		 
//		calling Admin Microservice for processing the data
		User user = restTemplate.postForObject("http://localhost:8080/api/admin/user/login", userDTO, User.class);
		if (user != null) {
			authUser = user;
			return new ApiResponse<>("User logged in successfully", user);
		} else {
			return new ApiResponse<>("User not found", user);
		}
	}


	@GetMapping("/logout")
	public ApiResponse<User> logoutUser() {
		userService.logoutUser(null);
		authUser = null;
		return new ApiResponse<>("User logged out successfully", authUser);
	}

	
//	Ask Question
	@PostMapping("/question/ask")
	public ApiResponse<Question> askQuestion(@RequestBody QuestionDTO questionDTO) {

		if (authUser == null) {
			
			return new ApiResponse<>("You are not Authorized user", null);
		}
		
		RestTemplate restTemplate = new RestTemplate();
		 
//		calling Admin Microservice for processing the data
		Question question = restTemplate.postForObject("http://localhost:8080/api/admin/user/question/ask", questionDTO, Question.class);

		return new ApiResponse<>("Question Posted successfully but pending with Admin", question);
	}

//    Search Question based on String.
	@GetMapping("questions/search/{word}")
	public ResponseEntity<?> searchQuestions(@PathVariable String word) {
		if (authUser == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

		List<Question> foundQuestions = questionService.searchQuestions(word);
		if (foundQuestions == null)
			return ResponseEntity.ok().body("No Question Found With Matching Word " + word);
		return ResponseEntity.ok().body(foundQuestions);
	}

//    view All approved questions
	@GetMapping("questions/viewall")
	public ResponseEntity<?> getAllApprovedQuestions() {
		if (authUser == null)
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");

		List<Question> approvedQuestions = questionService.getAllApprovedQuestions();
		if (approvedQuestions == null)
			return ResponseEntity.ok().body("No Approved Question At this time. ");

		return ResponseEntity.ok().body(approvedQuestions);
	}

//	get question by ID
	@GetMapping("/question/{id}")
	public ResponseEntity<?> getQuestionById(@PathVariable Long id) throws QuestionNotFoundException {
		if (authUser == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}
		Question question = questionService.findById(id);
		if (question != null && question.getStatus().equals(APPROVED)) {
			return ResponseEntity.ok().body(question);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Question not found with given id = " + id);
		}
	}

//	Add answer to question with id
	@PostMapping("/add/answer")
	public ApiResponse<Object> addAnswer(@RequestBody AnswerDTO answerDTO) throws QuestionNotFoundException {
		if (authUser == null) {

			return new ApiResponse<>("You are not an authorized user", null);
		}
		return answerService.save(answerDTO);

	}

//	like answer with answer id
	@PostMapping("/like/answer/{answerId}")
	public ApiResponse<?> likeAnswer(@PathVariable Long answerId) {
		if (authUser == null) {

			return new ApiResponse<>("You are not an authorized user", null);
		}
		
		return answerService.likeAnswerById(answerId);

		
	}

	// Comment on Answer with answer ID
	@PostMapping("/answer/comment")
	public ApiResponse<Comment> addCommentToAnswer(@RequestBody CommentDTO commentDTO) throws AnswerNotFoundException {
		if (authUser == null) {
			return new ApiResponse<>("You are not an authorized user", null);
		}
		return answerService.addCommentToAnswer(commentDTO);
	}

//	Get FUll details of Question with ID

	@GetMapping("/question/{id}/details")
	public ResponseEntity getQuestionDetails(@PathVariable long id) throws QuestionNotFoundException {
		if (authUser == null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
		}

		QuestionDetailsDTO questionDetailsDTO = questionService.getQuestionDetails(id);
		if (questionDetailsDTO != null) {

			return ResponseEntity.ok().body(new ApiResponse<>("Questions details founded", questionDetailsDTO));
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ApiResponse<>("Questions Details not found", null));
	}
	
	
}
