package com.hcl.doconnect.service;

import com.hcl.doconnect.repository.AnswerRepository;
import com.hcl.doconnect.repository.QuestionRepository;
import com.hcl.doconnect.controller.ApiResponse;
import com.hcl.doconnect.dto.AnswerDTO;
import com.hcl.doconnect.dto.CommentDTO;
import com.hcl.doconnect.model.Answer;
import com.hcl.doconnect.model.Comment;
import com.hcl.doconnect.model.Question;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

@Service
public class AnswerServiceImpl implements AnswerService {

	@Autowired
	private AnswerRepository answerRepository;
	@Autowired
	private QuestionRepository questionRepository;

	@Override
	public Answer findById(Long id) {
		Optional<Answer> optionalAnswer = answerRepository.findById(id);
		return optionalAnswer.orElse(null);
	}

	@Override
    public ApiResponse<Object> save(AnswerDTO answerDTO) {
		
		RestTemplate restTemplate = new RestTemplate();
		ApiResponse  response = restTemplate.postForObject("http://localhost:8080/api/admin/user/add/answer", answerDTO, ApiResponse.class);
		return response;
    }

	@Override
	public void delete(Answer answer) {
		answerRepository.delete(answer);
	}

	@Override
	public boolean approveAnswer(Long id) {
		Optional<Answer> optionalAnswer = answerRepository.findById(id);
		if (optionalAnswer.isPresent()) {
			Answer answer = optionalAnswer.get();
			answer.setStatus("APPROVED"); // Set the answer as approved
			answerRepository.save(answer);
			return true;
		}
		return false;
	}

	@Override
	public boolean deleteAnswer(Long id) {
		Optional<Answer> optionalAnswer = answerRepository.findById(id);
		if (optionalAnswer.isPresent()) {
			answerRepository.delete(optionalAnswer.get());
			return true;
		}
		return false;
	}

	@Override
	public ApiResponse<?> likeAnswerById(Long answerId) {
		RestTemplate restTemplate = new RestTemplate();
		ApiResponse  response = restTemplate.getForObject("http://localhost:8080/api/admin/user/like/answer/"+answerId,  ApiResponse.class);
		return response;
	}

	@Override
	public ApiResponse<Comment> addCommentToAnswer(CommentDTO commentDTO) {
		RestTemplate restTemplate = new RestTemplate();
		ApiResponse  response = restTemplate.postForObject("http://localhost:8080/api/admin/user/answer/comment", commentDTO, ApiResponse.class);
		return response;
	}
	

	

	// Add other methods as needed
}
